def query_knowledge_base(question: str):
    return {
        "answer": f"Here's a detailed explanation for: '{question}'. Always consult a medical professional."
    }
