from fastapi import FastAPI, Request
from qwen_api import analyze_symptoms
from clinic_finder import get_nearby_clinics
from langchain_chat import query_knowledge_base
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze")
async def analyze(request: Request):
    data = await request.json()
    return analyze_symptoms(data["symptoms"], data["age"])

@app.get("/nearby")
async def nearby(location: str):
    return get_nearby_clinics(location)

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    return query_knowledge_base(data["question"])
