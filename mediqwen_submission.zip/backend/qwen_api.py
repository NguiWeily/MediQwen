def analyze_symptoms(symptoms: str, age: str):
    return {
        "advice": f"Based on symptoms '{symptoms}', age {age}, you may have a mild flu. Stay hydrated and rest."
    }
