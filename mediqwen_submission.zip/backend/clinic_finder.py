def get_nearby_clinics(location: str):
    return {
        "clinics": [
            {"name": "Health Clinic A", "address": f"123 Main St, {location}"},
            {"name": "Care Center B", "address": f"456 Wellness Ave, {location}"}
        ]
    }
