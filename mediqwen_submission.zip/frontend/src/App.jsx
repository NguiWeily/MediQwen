import React, { useState } from 'react';
import InputForm from './components/InputForm';
import Results from './components/Results';

export default function App() {
  const [response, setResponse] = useState(null);

  return (
    <div className="min-h-screen bg-blue-50 p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">MediQwen: AI Health Advisor</h1>
      <InputForm setResponse={setResponse} />
      {response && <Results data={response} />}
    </div>
  );
}
