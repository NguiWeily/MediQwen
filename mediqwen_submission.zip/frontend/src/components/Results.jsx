import React from 'react';

export default function Results({ data }) {
  return (
    <div className="mt-6 max-w-xl mx-auto">
      <h2 className="text-xl font-bold mb-2">Health Advice:</h2>
      <p className="mb-4">{data.advice}</p>

      <h2 className="text-xl font-bold mb-2">Nearby Clinics:</h2>
      <ul className="list-disc list-inside mb-4">
        {data.clinics.map((clinic, index) => (
          <li key={index}>{clinic.name} - {clinic.address}</li>
        ))}
      </ul>

      <h2 className="text-xl font-bold mb-2">Follow-up Q&A:</h2>
      <p>{data.answer}</p>
    </div>
  );
}
