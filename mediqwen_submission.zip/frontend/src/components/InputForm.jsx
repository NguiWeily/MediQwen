import React, { useState } from 'react';
import axios from 'axios';

export default function InputForm({ setResponse }) {
  const [symptoms, setSymptoms] = useState('');
  const [age, setAge] = useState('');
  const [location, setLocation] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const analyze = await axios.post('http://localhost:8000/analyze', { symptoms, age });
    const clinics = await axios.get(`http://localhost:8000/nearby?location=${location}`);
    const chat = await axios.post('http://localhost:8000/chat', { question: symptoms });
    setResponse({ advice: analyze.data.advice, clinics: clinics.data.clinics, answer: chat.data.answer });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow max-w-md mx-auto">
      <label className="block mb-2">Symptoms:</label>
      <input type="text" className="w-full mb-4 border p-2" value={symptoms} onChange={(e) => setSymptoms(e.target.value)} />

      <label className="block mb-2">Age:</label>
      <input type="number" className="w-full mb-4 border p-2" value={age} onChange={(e) => setAge(e.target.value)} />

      <label className="block mb-2">Location:</label>
      <input type="text" className="w-full mb-4 border p-2" value={location} onChange={(e) => setLocation(e.target.value)} />

      <button type="submit" className="bg-blue-500 text-white py-2 px-4 rounded">Submit</button>
    </form>
  );
}
