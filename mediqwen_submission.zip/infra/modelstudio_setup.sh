#!/bin/bash
echo "Model Studio Qwen setup complete."